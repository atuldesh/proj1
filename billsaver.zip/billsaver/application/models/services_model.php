<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Name:  Ion Auth Model
 *
 * Author:  TIU
 * 		   ben.edmunds@gmail.com
 * 	  	   @benedmunds
 *
 * Added Awesomeness: Phil Sturgeon
 *
 * Location: http://github.com/benedmunds/CodeIgniter-Ion-Auth
 *
 * Created:  10.01.2009
 *
 * Description:  Modified auth system based on redux_auth with extensive customization.  This is basically what Redux Auth 2 should be.
 * Original Author name has been kept but that does not mean that the method has not been modified.
 *
 * Requirements: PHP5 or above
 *
 */
class Sale_model extends CI_Model {
    public $tables = array();
    public function __construct() {
        parent::__construct();
        $this->load->database();
       // initialize db tables data
    }
    public function update($data, $id) {
			$this->db->where('serid', $serid); 
       		$this->db->update('services', $data);
    }       
    public function insert($data) {
       		$this->db->insert('services', $data);
    }       
      public function fetchdata($count = false, $limit, $page) {
              
	$this->db->select('*');
    	$this->db->from('services');
//        $this->db->where(array('sdate >= ' => date('Y-m-d', $fdate), 'sdate <= ' => date('Y-m-d', $tdate)));
        $this->db->order_by("service", "asc");
               if($count){ return $this->db->get()->num_rows();}
		else{
                    $this->db->limit($limit, $page);
                    return $this->db->get()->result(); 
                    
                }       
    }
        public function service($serid){
        $this->db->select('*');
    	$this->db->from('services');
        $this->db->where(array('serid' => $serid));
        return $this->db->get()->row();            
        }
    
    public function delete($id) { 
        return $this->db->delete('scervices', array('serid' => $serid));
    }
  
}