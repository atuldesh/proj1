<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
ini_set('memory_limit', '-1');
/**
* Name:  Ion Auth Model
*
* Author:  TIU
* 		   ben.edmunds@gmail.com
*	  	   @benedmunds
*
* Added Awesomeness: Phil Sturgeon
*
* Location: http://github.com/benedmunds/CodeIgniter-Ion-Auth
*
* Created:  10.01.2009
*
* Description:  Modified auth system based on redux_auth with extensive customization.  This is basically what Redux Auth 2 should be.
* Original Author name has been kept but that does not mean that the method has not been modified.
*
* Requirements: PHP5 or above
*
*/

class csv_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }
	
	
	
	
	
    function uploadData()
    {
        $count=0;
		 $this->db->truncate('temp');
        $fp = fopen($_FILES['reportfile']['tmp_name'],'r') or die("can't open file");
		
		
        while($csv_line = fgetcsv($fp,1024))
        {
            $count++;
            //if($count == 1)
            //{
              //  continue;
            //}//keep this if condition if you want to remove the first row
		
			
            for($i = 0, $j = count($csv_line); $i < $j; $i++)
            {
                $insert_csv = array();
                $insert_csv['tdate'] = date('Y-m-d', strtotime($csv_line[0]));//remove if you want to have primary key,	
				$query = $this->db->get_where('locations', array('locid' => $csv_line[2]));	
				$location = $query->row_array();			
                $insert_csv['location'] = $location['location'];
                $insert_csv['camt'] = $csv_line[3];				
            }
			
				
			
            $i++;
           	 $data = array(
                'tdate' => $insert_csv['tdate'] ,
                'location' => $insert_csv['location'],
                'camt' => $insert_csv['camt']);
				
				
          		 $this->db->insert('temp', $data);
        }
        fclose($fp) or die("can't close file");
        return "success";
    }
}