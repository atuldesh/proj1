<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<table class="table table-bordered" id="tableList">
  <thead>
   <tr>
		<th>Sr. No.</th>
		<th>IEMI Number</th>
		<th>S.Date</th>
		<th>Created By</th>
		<th>Holder</th>
		<th>Status</th>
		<th>Status Since</th>
		<th>Changed By</th>
		<th>Remark</th>
		<th>History</th>
	</tr>
  </thead>
  <tbody>
   <?php $count = 1; foreach ($jobs as $job): ?>
		<tr>
			<td><?php echo htmlspecialchars($count,ENT_QUOTES,'UTF-8');?></td>
			<td><?php echo htmlspecialchars($job->imeino,ENT_QUOTES,'UTF-8');?></td>
			<td><?php echo htmlspecialchars($job->createdBy,ENT_QUOTES,'UTF-8');?></td>
			<td><?php echo htmlspecialchars($job->currentHolder,ENT_QUOTES,'UTF-8');?></td>
			<td><?php echo htmlspecialchars($job->status,ENT_QUOTES,'UTF-8');?></td>
			<td><?php echo htmlspecialchars($job->statusChangeDate,ENT_QUOTES,'UTF-8');?></td>
			<td><?php echo htmlspecialchars($job->statusChangeBy,ENT_QUOTES,'UTF-8');?></td>
			<td><?php echo htmlspecialchars($job->remark,ENT_QUOTES,'UTF-8');?></td>
			<td><?php echo anchor("job/save/".$job->jobid, 'Edit') ;?> &nbsp;<?php echo anchor("job/delete/".$job->jobid, 'Delete') ;?> </td>
	</tr>
	<?php $count++; endforeach;?>
  </tbody>
</table>