<?php $this->load->view('headernew'); ?>

<!-- /.navbar-collapse -->
<div class="row subheader">
    <!-- Page Content -->
    <div class="container">
        <div class="panel-heading">
            <div class="panel-title text-center">Change Password</div>
        </div>
    </div>
    <div>
        </nav>   

        <!-- Header -->
        <header>
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div style="clear:both;"></div>
                        <br>
                        <div id="loginbox" class="mainbox col-md-6 col-md-offset-3 col-sm-6 col-sm-offset-3">
                            <div class="panel panel-default" >

                                <div class="panel-body" >
                                    <div id="infoMessage"><?php echo $message; ?></div>

                                    <?php echo form_open("auth/change_password"); ?>

                                    <p>
                                        <?php echo lang('change_password_old_password_label', 'old_password'); ?> <br />
                                        <?php echo form_input($old_password); ?>
                                    </p>

                                    <p>
                                        <label for="new_password"><?php echo sprintf(lang('change_password_new_password_label'), $min_password_length); ?></label> <br />
                                        <?php echo form_input($new_password); ?>
                                    </p>

                                    <p>
                                        <?php echo lang('change_password_new_password_confirm_label', 'new_password_confirm'); ?> <br />
                                        <?php echo form_input($new_password_confirm); ?>
                                    </p>

                                    <?php echo form_input($user_id); ?>
                                    <button type="submit" href="#" class="btn btn-primary pull-right"><i class="glyphicon glyphicon-log-in"></i> Change Password</button>
                                    <?php echo form_close(); ?> 
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>


        <?php $this->load->view('footernew'); ?>