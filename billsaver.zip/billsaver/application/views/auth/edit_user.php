<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><?php $this->load->view('headernew'); ?>

<!-- /.navbar-collapse -->
<div class="row subheader">
    <!-- Page Content -->
    <div class="container">
       <div class="panel-heading">
  <div class="panel-title text-center">Edit User</div>
</div>
    </div>
<div>
        </nav>   



        <!-- Header -->
        <header>
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div style="clear:both;"></div>
                        <div id="loginbox" class="mainbox col-md-6 col-md-offset-3 col-sm-6 col-sm-offset-3">
<div class="panel panel-default" >

                       <div class="panel-body" >
<div id="infoMessage"><?php echo $message;?></div>
<?php echo form_open(uri_string());?>
<div class="col-md-4 col-sm-12"><?php echo lang('edit_user_fname_label', 'first_name');?> </div>
<div class="col-md-8 col-sm-12"><?php echo form_input($first_name);?> </div>
<p>  <br />
  </p>

<div class="col-md-4 col-sm-12"><?php echo lang('edit_user_lname_label', 'last_name');?></div>
<div class="col-md-8 col-sm-12"><?php echo form_input($last_name);?>  </div>
<p>  <br />
  </p>

<div class="col-md-4 col-sm-12"><?php echo lang('edit_user_company_label', 'company');?> </div>
<div class="col-md-8 col-sm-12"> <?php echo form_input($company);?></div>
<p>  <br />
  </p>
  <div style="clear:both;"></div>
<div class="col-md-4 col-sm-12"><?php echo lang('edit_user_phone_label', 'phone');?>  </div>
<div class="col-md-8 col-sm-12"><?php echo form_input($phone);?>  </div>
<p>  <br />
  </p><div style="clear:both;"></div>
<div class="col-md-4 col-sm-12"><?php echo lang('edit_user_password_label', 'password');?></div>
<div class="col-md-8 col-sm-12"><?php echo form_input($password);?> </div>
<p>  <br />
  </p><div style="clear:both;"></div>
<div class="col-md-4 col-sm-12"><?php echo lang('edit_user_password_confirm_label', 'password_confirm');?> </div>
<div class="col-md-8 col-sm-12"><?php echo form_input($password_confirm);?>  </div>
<p>  <br />
  </p><div style="clear:both;"></div>
  <div class="edit_user_checkbox" >
  <?php if ($this->ion_auth->is_admin()): ?>
  <div class="col-md-4 col-sm-12"> <b><?php echo lang('edit_user_groups_heading');?></b> </div>
<div class="col-md-8 col-sm-12"> <?php foreach ($groups as $group):?>
  <div class="checkbox col-md-12 pull-left">
  <?php
                  $gID=$group['id'];
                  $checked = null;
                  $item = null;
                  foreach($currentGroups as $grp) {
                      if ($gID == $grp->id) {
                          $checked= ' checked="checked"';
                      break;
                      }
                  }
              ?>
      
  <input type="checkbox" class="pull-left" name="groups[]" value="<?php echo $group['id'];?>"<?php echo $checked;?>>
  <?php echo htmlspecialchars($group['name'], ENT_QUOTES, 'UTF-8');?> </div>
  <?php endforeach?>  </div>
  
  

 
 
  <?php endif ?>
  <?php echo form_hidden('id', $user->id);?> <?php echo form_hidden($csrf); ?> </div>
<button type="submit" href="#" class="btn btn-primary pull-right"><i class="glyphicon glyphicon-log-in"></i> Edit User</button>
<?php echo form_close();?> 
</div>
                    </div>
                </div>
            </div>
                </div>
            </div>
        </header>

        <?php $this->load->view('footernew'); ?>