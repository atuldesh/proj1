<?php $this->load->view('headernew'); ?>

<!-- /.navbar-collapse -->
<div class="row subheader">
    <!-- Page Content -->
    <div class="container">
       <div class="panel-heading">
  <div class="panel-title text-center">Create User</div>
</div>
    </div>
<div>
        </nav>   



        <!-- Header -->
        <header>
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div style="clear:both;"></div><br>
                        <div id="loginbox" class="mainbox col-md-6 col-md-offset-3 col-sm-6 col-sm-offset-3">
<div class="panel panel-default" >

                       <div class="panel-body" >
<?php echo form_open("auth/deactivate/".$user->id);?>

  </p><div style="clear:both;"></div>
<div class="col-md-2 col-sm-12"><?php echo lang('deactivate_confirm_y_label', 'confirm');?> 
        <br><input type="radio" name="confirm" value="yes" checked="checked" /></div>
<div class="col-md-4 col-sm-12"> 
    <?php echo lang('deactivate_confirm_n_label', 'confirm');?><br>
    <input type="radio" name="confirm" value="no" />  </div>

<div style="clear:both;"></div>



  <?php echo form_hidden($csrf); ?>
  <?php echo form_hidden(array('id'=>$user->id)); ?>

            <button type="submit" href="#" class="btn btn-primary pull-right"><i class="glyphicon glyphicon-log-in"></i> Update</button>

              <?php echo form_close();?>
  
  

            </div>
                    </div>
                </div>
            </div>
                </div>
            </div>
        </header>

        <?php $this->load->view('footernew'); ?>

