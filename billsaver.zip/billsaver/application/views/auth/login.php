<?php $this->load->view('headernew'); ?>
<!-- /.navbar-collapse -->

<div class="row subheader">
<!-- Page Content -->
<div class="container">
  <div class="panel-heading">
    <div class="panel-title text-center">Login</div>
  </div>
</div>
<div>
</nav>
<!-- Header -->
<header>
  <div class="container">
    <div class="row">
      <div class="col-lg-2 col-sm-12"></div>
      <div class="col-lg-8 col-sm-12">
        <div style="clear:both;"></div>
        <br>
        <div id="loginbox" class="mainbox col-md-6 col-md-offset-3 col-sm-6 col-sm-offset-3">
          <div class="panel panel-default" >
            <div class="panel-body" >
              <div id="infoMessage"><?php echo $message; ?></div>
              <?php echo form_open("auth/login"); ?>
              <div class="input-group"> <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span> <?php echo form_input($identity); ?> </div>
              <div class="col-md-12">&nbsp;</div>
              <div class="input-group"> <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span> <?php echo form_input($password); ?> </div>
              <div class="col-md-12">&nbsp;</div>
              <div class="input-group"> <?php echo lang('login_remember_label', 'remember'); ?>&nbsp;<?php echo form_checkbox('remember', '1', FALSE, 'id="remember"'); ?> </div>
              <div class="form-group">
                <!-- Button -->
                <div class="col-sm-12 controls">
                  <button type="submit" href="#" class="btn btn-primary pull-left"><i class="glyphicon glyphicon-log-in"></i> Log in</button>
                  <p><a href="forgot_password"  class="fpwd pull-right"><?php echo lang('login_forgot_password'); ?></a></p>
                </div>
              </div>
              <?php echo form_close(); ?> </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</header>
<?php $this->load->view('footernew'); ?>
