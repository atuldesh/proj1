<?php $this->load->view('headernew'); ?>
<!-- /.navbar-collapse -->

<div class="row subheader">
<!-- Page Content -->
<div class="container">
  <div class="panel-heading">
    <div class="panel-title text-center">Forgot Password</div>
  </div>
</div>
<div>
</nav>
<!-- Header -->
<header>
  <div class="container">
    <div class="row">
      <div class="col-lg-2 col-sm-12"></div>
      <div class="col-lg-8 col-sm-12">
        <div style="clear:both;"></div>
        <br>
        <div id="loginbox" class="mainbox col-md-6 col-md-offset-3 col-sm-6 col-sm-offset-3">
          <div class="panel panel-default" >
            <div class="panel-body" >
              <div id="infoMessage"><?php echo $message; ?></div>
              <?php echo form_open("auth/forgot_password");?>
              <p>
                <label for="identity"><?php echo (($type=='email') ? sprintf(lang('forgot_password_email_label'), $identity_label) : sprintf(lang('forgot_password_identity_label'), $identity_label));?></label>
                <br />
                <?php echo form_input($identity);?> </p>
              <button type="submit" href="#" class="btn btn-primary pull-right"><i class="glyphicon glyphicon-log-in"></i> Forgot Password</button>
              <p><a href="login"  class="btn btn-primary pull-left">Login</a></p>
              <?php echo form_close();?> </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</header>
<?php $this->load->view('footernew'); ?>
