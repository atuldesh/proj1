<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<meta name="author" content="">
<title>Billing Software</title>
<!-- Bootstrap Core CSS -->
<link href="<?=base_url()?>assests/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<!-- Theme CSS -->
<link href="<?=base_url()?>assests/css/freelancer.css" rel="stylesheet">
<!-- Custom Fonts -->
<link href="<?=base_url()?>assests/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"> </script>
<link rel="apple-touch-icon" sizes="57x57" href="<?=base_url()?>assests/favicon/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="<?=base_url()?>assests/favicon/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="<?=base_url()?>assests/favicon/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="<?=base_url()?>assests/favicon/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="<?=base_url()?>assests/favicon/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="<?=base_url()?>assests/favicon/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="<?=base_url()?>assests/favicon/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="<?=base_url()?>assests/favicon/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="<?=base_url()?>assests/favicon/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="<?=base_url()?>assests/favicon/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="<?=base_url()?>assests/favicon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="<?=base_url()?>assests/favicon/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="<?=base_url()?>assests/favicon/favicon-16x16.png">
<link rel="manifest" href="<?=base_url()?>assests/fevicon/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="<?=base_url()?>assests/favicon/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">
<link href="https://cdn.datatables.net/1.10.13/css/jquery.dataTables.min.css" rel="stylesheet">
<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

<body>

<!-- Navigation -->
<nav id="mainNav" class="navbar navbar-default navbar-fixed-top navbar-custom">
	<div class="container">
<!-- Brand and toggle get grouped for better mobile display -->
		<div class="navbar-header page-scroll">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1"> <span class="sr-only">Toggle navigation</span> Menu <i class="fa fa-bars"></i> </button>
			<a class="navbar-brand" href="#page-top">Billing Software</a><h6><a><?php echo $this->data['title']; ?></a></h6> 
		</div>

<!-- Collect the nav links, forms, and other content for toggling -->
		<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
			<ul class="nav navbar-nav navbar-right">
				<li><a>Welcome :: <?php if($this->ion_auth->user()->row()->first_name): echo $this->ion_auth->user()->row()->first_name.' '.$this->ion_auth->user()->row()->last_name; else: echo 'Guest'; endif; ?></a></li>
  <?php if ($this->ion_auth->logged_in()): ?>
				<li>
					<div class=" btn btn-group"> <a class="btn dropdown-toggle" data-toggle="dropdown" href="#"> Menu <span class="caret"></span> </a>
      <?php //echo $this->ion_auth->get_users_groups()->row()->id; ?>
						<ul class="dropdown-menu dropdown-menu_new">
        <?php if ($this->ion_auth->is_admin() || $this->ion_auth->in_group('Su')): ?>
							<li><a href="<?php echo base_url('/auth/index'); ?>">Users</a></li>
							<li><a href="<?php echo base_url('/sale'); ?>">Sales</a></li>
							<li><a href="<?php echo base_url('/purchase'); ?>">Purchase</a></li>
							<li><a href="<?php echo base_url('/jobs'); ?>">complaint</a></li>
		<?php endif; ?>
						</ul>
					</div>
				</li>
				<li>
					<div class=" btn btn-group">
						<a href="<?php echo base_url('/auth/logout'); ?>" class="btn dropdown-toggle">Logout</a> 
					</div>
				</li>
  <?php 
				else:
				?>
				<li>
					<div class=" btn btn-group">
						<a href="<?php echo base_url('/auth/login'); ?>" class="btn dropdown-toggle">Login</a>
					</div>
				</li>
  <?php endif;  ?>
			</ul>
		</div>
<!-- /.navbar-collapse -->
	</div>

<!-- /.container-fluid --> 

