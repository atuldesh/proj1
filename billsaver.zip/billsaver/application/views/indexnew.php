<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><?php $this->load->view('headernew'); ?>

<!-- /.navbar-collapse -->
<div class="row subheader">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assests/css/bootstrap-datepicker.css">
    <!-- Page Content -->
    <div class="container">
        <!-- Jumbotron Header -->
        <header class="hero-spacer_inner">

            <div class="col-md-12">&nbsp;</div>
        </header>
      

        </nav>   



        <!-- Header -->
        <header>
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div style="clear:both;"></div>
                        <div id="loginbox" class="mainbox col-md-6 col-md-offset-3 col-sm-6 col-sm-offset-3">
<div class="panel panel-default" >
<div class="panel-heading">
  <div class="panel-title text-center">Edit User</div>
</div>
                       <div class="panel-body" >
<div id="infoMessage"><?php echo $message;?></div>
<?php echo form_open(uri_string());?>
<p> <?php echo lang('edit_user_fname_label', 'first_name');?> <br />
  <?php echo form_input($first_name);?> </p>
<p> <?php echo lang('edit_user_lname_label', 'last_name');?> <br />
  <?php echo form_input($last_name);?> </p>
<p> <?php echo lang('edit_user_company_label', 'company');?> <br />
  <?php echo form_input($company);?> </p>
<p> <?php echo lang('edit_user_phone_label', 'phone');?> <br />
  <?php echo form_input($phone);?> </p>
<p> <?php echo lang('edit_user_password_label', 'password');?> <br />
  <?php echo form_input($password);?> </p>
<p> <?php echo lang('edit_user_password_confirm_label', 'password_confirm');?><br />
  <?php echo form_input($password_confirm);?> </p>
<div class="edit_user_checkbox" >
  <?php if ($this->ion_auth->is_admin()): ?>
  <b><?php echo lang('edit_user_groups_heading');?></b>
  <?php foreach ($groups as $group):?>
  <label class="checkbox">
  <?php
                  $gID=$group['id'];
                  $checked = null;
                  $item = null;
                  foreach($currentGroups as $grp) {
                      if ($gID == $grp->id) {
                          $checked= ' checked="checked"';
                      break;
                      }
                  }
              ?>
  <input type="checkbox" name="groups[]" value="<?php echo $group['id'];?>"<?php echo $checked;?>>
  <?php echo htmlspecialchars($group['name'], ENT_QUOTES, 'UTF-8');?> </label>
  <?php endforeach?>
  <?php endif ?>
  <?php echo form_hidden('id', $user->id);?> <?php echo form_hidden($csrf); ?> </div>
<button type="submit" href="#" class="btn btn-primary pull-right"><i class="glyphicon glyphicon-log-in"></i> Edit User</button>
<?php echo form_close();?> 
</div>
                    </div>
                </div>
            </div>
                </div>
            </div>
        </header>

        <?php $this->load->view('footernew'); ?>