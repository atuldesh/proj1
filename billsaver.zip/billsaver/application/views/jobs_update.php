<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><?php $this->load->view('headernew'); ?>

<!-- /.navbar-collapse -->
<div class="row subheader">
    <!-- Page Content -->
    <div class="container">
       <div class="panel-heading">
			<div class="panel-title text-center"><?=$title;?></div>
		</div>
    </div></nav>  
	<div>
        <!-- Header -->
        <header>
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div style="clear:both;"></div>
                        <div id="loginbox" class="mainbox col-md-6 col-md-offset-3 col-sm-6 col-sm-offset-3">
							<div class="panel panel-default" >
								<div class="panel-body" >
									<div id="infoMessage"><?php echo $message;?></div>
<?php echo form_open(uri_string());?>
									<div class="col-md-4 col-sm-12">IEMI Number </div>
									<div class="col-md-8 col-sm-12"><?php echo form_input($imeino);?> </div>
									<p><br /></p>
									<div class="col-md-4 col-sm-12">Job Date</div>
									<div class="input-group date" data-provide="datepicker" data-date-autoclose="true" data-date-orientation="bottom auto">									<p>  <br />  </p>
										<div class="input-group-addon">
											<span class="glyphicon glyphicon-th"></span>
										</div>
									</div>
									<div class="col-md-4 col-sm-12">Owner Name</div>
									<div class="col-md-8 col-sm-12"><?php echo form_input($ownerName);?>  </div>
									<p>  <br />  </p>
									<div class="col-md-4 col-sm-12">Owner Address</div>
									<div class="col-md-8 col-sm-12"><?php echo form_input($ownerAddr);?>  </div>
									<p>  <br />  </p>
									<div class="col-md-4 col-sm-12">Owner Mobile</div>
									<div class="col-md-8 col-sm-12"><?php echo form_input($ownerMobile);?>  </div>
									<p>  <br />  </p>
					 			    <div class="col-md-4 col-sm-12">Current Holder</div>
									<div class="col-md-8 col-sm-12"><?php echo form_dropdown($currentHolder);?>  </div>
									<p>  <br />  </p>
					 			    <div class="col-md-4 col-sm-12">Status</div>
									<div class="col-md-8 col-sm-12"><?php echo form_dropdown($status);?>  </div>
									<p>  <br />  </p>
									<div class="col-md-4 col-sm-12">Status Change Date</div>
									<div class="input-group date" data-provide="datepicker" data-date-autoclose="true" data-date-orientation="bottom auto">									<p>  <br />  </p>
										<div class="input-group-addon">
											<span class="glyphicon glyphicon-th"></span>
										</div>
									</div>
									 <div class="col-md-4 col-sm-12">Remark </div>
									<div class="col-md-8 col-sm-12"> <?php echo form_input($remark);?></div>
									<p>  <br />  </p>
									<p>  <br />  </p><div style="clear:both;"></div>
									<p>  <br />  </p>
									<div class="edit_user_checkbox" >
										<?php echo form_hidden('id', $sale->id);?> 
									</div>
									<a href="<?=base_url('sale/index');?>" class="btn btn-primary pull-left">Back</a>  
									<button type="submit" href="#" class="btn btn-primary pull-right"><i class="glyphicon glyphicon-log-in"></i> Save</button>
<?php echo form_close();?> 
								</div>
							</div>
						</div>
					</div>
                </div>
            </div>
        </header>
	</div>
</div>
 <?php $this->load->view('footernew'); ?>