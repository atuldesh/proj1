<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><?php $this->load->view('headernew'); ?>

<!-- /.navbar-collapse -->
<div class="row subheader">
    <!-- Page Content -->
    <div class="container">
       <div class="panel-heading">
  <div class="panel-title text-center"><?=$title;?></div>
</div>
    </div>
<div>
        </nav>   
        <!-- Header -->
        <header>
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div style="clear:both;"></div>
                        <div id="loginbox" class="mainbox col-md-6 col-md-offset-3 col-sm-6 col-sm-offset-3">
<div class="panel panel-default" >

                       <div class="panel-body" >
<div id="infoMessage"><?php echo $message;?></div>
<?php echo form_open(uri_string());?>
<div class="col-md-4 col-sm-12">IEMI Number </div>
<div class="col-md-8 col-sm-12"><?php echo form_input($imeino);?> </div>
<p>  <br />
  </p>
<div class="col-md-4 col-sm-12">Model</div>
<div class="col-md-8 col-sm-12"><?php echo form_input($model);?>  </div>
<p>  <br />
  </p>
<div class="col-md-4 col-sm-12">Company</div>
<div class="col-md-8 col-sm-12"><?php echo form_input($company);?>  </div>
<p>  <br />
  </p>

<div class="col-md-4 col-sm-12">Invoice No. </div>
<div class="col-md-8 col-sm-12"> <?php echo form_input($invoiceno);?></div>
<p>  <br />
  </p>
  <div style="clear:both;"></div>
<div class="col-md-4 col-sm-12">Billed By  </div>
<div class="col-md-8 col-sm-12"><?php echo form_input($billedby);?>  </div>
<p>  <br />
  </p><div style="clear:both;"></div>
  <div style="clear:both;"></div>
<div class="col-md-4 col-sm-12">Mobile No. </div>
<div class="col-md-8 col-sm-12"><?php echo form_input($mobileno);?>  </div>
<p>  <br />
  </p><div style="clear:both;"></div>
  <div style="clear:both;"></div>
<div class="col-md-4 col-sm-12">Purchase Date  </div>
<div class="col-md-8 col-sm-12"> 

  <div class="input-group date" data-provide="datepicker" data-date-autoclose="true" data-date-orientation="bottom auto">
   <?php echo form_input($pdate);?>
    <div class="input-group-addon">
        <span class="glyphicon glyphicon-th"></span>
    </div>
</div>

</div>
<p>  <br />
  </p><div style="clear:both;"></div>
  
<div class="col-md-4 col-sm-12">Remark  </div>
<div class="col-md-8 col-sm-12"><?php echo form_input($remark);?>  </div>
<p>  <br />
   <div style="clear:both;"></div>
<div class="col-md-4 col-sm-12">Scheme Name </div>
<div class="col-md-8 col-sm-12"><?php echo form_input($schemeid);?>  </div>
<p>  <br />
  </p><div style="clear:both;"></div>
  
<p>  <br />
  </p>
  <div class="edit_user_checkbox" >
  <?php echo form_hidden('id', $purchase->id);?> 
</div>
  <a href="<?=base_url('purchase/index');?>" class="btn btn-primary pull-left">Back</a>  
<button type="submit"  class="btn btn-primary pull-right"><i class="glyphicon glyphicon-log-in"></i> Save Purchase</button>
<?php echo form_close();?> 
</div>
                    </div>
                </div>
            </div>
                </div>
            </div>
        </header>
<?php $this->load->view('footernew'); ?>