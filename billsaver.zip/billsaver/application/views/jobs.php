<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
?><?php $this->load->view('headernew'); ?>

<!-- /.navbar-collapse -->
<div class="row subheader">
    <!-- Page Content -->
    <div class="container">
        <!-- Jumbotron Header -->
        <header class="hero-spacer_inner">
            <div class="panel-heading">
                <div class="panel-title text-center">
					<div class="col-md-6">    
						<form action ="<?=base_url('sale/index');?>" method="post" id="searchform" default="false">
							<div class="panel-title hide text-center">Collections</div> 
							<div class="input-group pull-left date col-md-6 date">
								<div class="input-daterange input-group" id="datepicker">
									<input type="text" class="input-sm form-control" name="fdate" id="fdate" required="" />
									<span class="input-group-addon">to</span>
									<input type="text" class="input-sm form-control" name="tdate" id="tdate" required="" />
								</div>
							</div>
							<div class="col-md-3">
								<input type="submit" value="Search" class="pull-left btn btn-primary" id="submit" />
							</div>
						</form>
					</div>
				</div>
            </div>     
        </header></nav>
		
    </div>  
</div>	
        <!-- Header -->
    <header>
        <div class="container">
            <div class="row">
				<div class="col-lg-12">
                    <p class="pull-right">
						<?php echo anchor('sale/save', 'Add Entry')?> 
					</p>
                    <div style="clear:both;"></div>
                    <div id="loginbox" class="mainbox col-md-12 col-sm-12 "> 
						<div class="panel panel-default" >
							<div class="panel-body" >
								<div id="infoMessage"><?php echo $message;?></div>
								<div id="ajaxdata">
								  <?php $this->load->view('jobsajaxview'); ?>
								</div>  
							</div>  
						</div>
                    </div>
                </div>
            </div>
		</div>
    </header>
    <?php $this->load->view('footernew'); ?> 

	<script src="<?php echo base_url(); ?>assests/js/bootstrap-datepicker.js"></script>
	<script src="<?php echo base_url(); ?>assests/js/bootstrap-confirmation.min.js"></script>
	<script type="text/javascript">
		$(document).ready(function() {
			$.extend( true, $.fn.dataTable.defaults, {
				"searching": false,
				"paging":   false,
			} );
			 $('#tableList').DataTable( {
				responsive: false,
			} );
			$('#datepicker').datepicker({
				toggleActive: true,
				autoclose: true,
			});
			
		} );

		$("#searchform").submit(function(e) {
			var url = "<?=base_url('job/index');?>"; // the script where you handle the form input.
			$.ajax({
			   type: "POST",
			   url: url,
			   data: $("#searchform").serialize(), // serializes the form's elements.
			   beforeSend : function(arr, $form, options){ 
			   $("#ajaxdata").html('<div class="loading">Loading&#8230;</div>');
			   },
			   success: function(data)
			   {
				   $("#ajaxdata").html(data);
			   }
			});
		 e.preventDefault(); // avoid to execute the actual submit of the form.
		});
</script>
