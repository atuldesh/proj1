<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<table class="table table-bordered" id="tableList">
  <thead>
   <tr>
		<th>Sr.No.<th>
		<th>Service</th>
		<th>Rate</th>
		<th>Description</th>
		<th>Action</th>
	</tr>
  </thead>
  <tbody>
   <?php $count = 1; foreach ($services as $service): ?>
		<tr>
			<td><?php echo htmlspecialchars($count,ENT_QUOTES,'UTF-8');?></td>
			<td><?php echo htmlspecialchars($service->service,ENT_QUOTES,'UTF-8');?></td>
			<td><?php echo htmlspecialchars($service->rate,ENT_QUOTES,'UTF-8');?></td>
			<td><?php echo htmlspecialchars($service->description,ENT_QUOTES,'UTF-8');?></td>
			<td><?php echo anchor("service/save/".$service->serid, 'Edit') ;?> &nbsp;<?php echo anchor("service/delete/".$service->serid, 'Delete') ;?> </td>
	</tr>
	<?php $count++; endforeach;?>
  </tbody>
</table>