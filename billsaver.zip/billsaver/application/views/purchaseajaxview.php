<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<table class="table table-bordered" id="tableList">
  <thead>
   <tr>
		<th>Sr. No.</th>
		<th>IEMI Number</th>
		<th>Company</th>
		<th>Model</th>
                <th>Purchase Date</th>
		
                <th>Invoice No.</th>
                <th>Scheme Id</th>
		<th>Action</th>
	</tr>
  </thead>
  <tbody>
   <?php $count = 1; foreach ($purchases as $purchase): ?>
		<tr>
            <td><?php echo htmlspecialchars($count,ENT_QUOTES,'UTF-8');?></td>
            <td><?php echo htmlspecialchars($purchase->imeino,ENT_QUOTES,'UTF-8');?></td>
            <td><?php echo htmlspecialchars($purchase->company,ENT_QUOTES,'UTF-8');?></td>
             <td><?php echo htmlspecialchars($purchase->model,ENT_QUOTES,'UTF-8');?></td>
              <td><?php echo htmlspecialchars($purchase->pdate,ENT_QUOTES,'UTF-8');?></td>
              <td><?php echo htmlspecialchars($purchase->invoiceno,ENT_QUOTES,'UTF-8');?></td>
              <td><?php echo htmlspecialchars($purchase->schemeid,ENT_QUOTES,'UTF-8');?></td>
              <td><?php echo anchor("purchase/save/".$purchase->id, 'Edit') ;?> &nbsp;<?php echo anchor("purchase/delete/".$purchase->id, 'Delete') ;?> </td>
	</tr>
	<?php $count++; endforeach;?>
  </tbody>
</table>