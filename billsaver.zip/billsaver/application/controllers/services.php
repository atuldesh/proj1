<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Services extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	 
	 	public function __construct()
		{
			error_reporting(1);
			parent::__construct();
			$this->load->database();
			$this->load->library(array('ion_auth','form_validation','pagination'));
			$this->lang->load('auth');
			$this->load->helper(array('url','language','form'));
			
			$this->load->model('services_model');
 			$this->form_validation->set_error_delimiters($this->config->item('error_start_delimiter', 'ion_auth'), $this->config->item('error_end_delimiter', 'ion_auth'));
			if (!$this->ion_auth->logged_in()): redirect('/auth/login'); endif;
			        
		}
		
	public function save($serid = NULL){

            if($this->input->post('imeino')){

                $servicedata['serid'] = $this->input->post('serid');
                $servicedata['service'] = $this->input->post('service');
                $servicedata['ret_id'] = $this->input->post('ret_id');
                $servicedata['rate'] = $this->input->post('rate');
                $servicedata['description'] = $this->input->post('description');
                
                if($this->input->post('serid'))
                {
                  $this->services_model->update($servicedata, $this->input->post('serid'));    
                    
                }else{
                $this->services_model->insert($servicedata);    
                }
                redirect('services/index');
            }
            if($serid){
                $service = $this->services_model->service($serid);
                $this->data['service'] = $service;
            }
            
                 $this->data['serno'] = array('name' => 'Serive Id',
				'id'    => 'serno',
				'type'  => 'text',
				'class'  => 'form-control',
//				'required' => 'required',
				'value' => $this->form_validation->set_value('serid', $service->serid),
			);   
                  $this->data['service'] = array('name' => 'Service',
				'id'    => 'Service',
				'type'  => 'text',
				'class'  => 'form-control',
				'required' => 'required',
				'value' => $this->form_validation->set_value('Service', $service->invoiceno),
			); 
                  $this->data['rate'] = array('name' => 'rate',
				'id'    => 'rate',
				'type'  => 'text',
				'class'  => 'form-control',
//				'required' => 'required',
				'value' => $this->form_validation->set_value('rate', $service->rate),
			);  
                  $this->data['description'] = array('name' => 'description',
				'id'    => 'description',
				'type'  => 'text',
				'class'  => 'form-control',
				'required' => 'required',
				'value' => $this->form_validation->set_value('Description', $service->description),
			);  
   
		$this->data['title'] = "Add service";	
		$this->load->view('services_save', $this->data, false);	
	}
        public function index()
	{
	
		$config["base_url"] 			= base_url() . "services/index/";
		$config["total_rows"] 			= $this->services_model->fetchdata(true);
		$config["per_page"] 			= 20;
		$config["uri_segment"] 			= 5;
		$config["num_links"] 			= 10;
		$config['full_tag_open'] 		= "<ul class='pagination' id='ajax_pagingsearc'>";
		$config['full_tag_close'] 		= "</ul>";
		$config['num_tag_open'] 		= '<li>';
		$config['num_tag_close'] 		= '</li>';
		$config['cur_tag_open'] 		= "<li class='disabled'><li class='active'><a href='#'>";
		$config['cur_tag_close'] 		= "<span class='sr-only'></span></a></li>";
		$config['next_tag_open'] 		= "<li>";
		$config['next_tagl_close'] 		= "</li>";
		$config['prev_tag_open'] 		= "<li>";
		$config['prev_tagl_close'] 		= "</li>";
		$config['first_tag_open'] 		= "<li>";
		$config['first_tagl_close'] 	= "</li>";
		$config['last_tag_open'] 		= "<li>";
		$config['last_tagl_close'] 		= "</li>";

    	$this->pagination->initialize($config);
	    $page = ($this->uri->segment(5))? $this->uri->segment(4) : 0;
        $this->data['service']= $this->services_model->fetchdata(fdate, $tdate, false, $config["per_page"], $page);
		$this->data["links"] = $this->pagination->create_links();
        $this->data['title'] = "Services";
                            
                
		if($ajax){                    
                $this->load->view('servicesajaxview',$this->data, false);
		}else{  $this->load->view('services',$this->data, false); }
	}
	
	
	public function delete($id){
		$this->services_model->delete($id); 
                redirect('services/index');
		exit;
	}
		
}
