<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Collection extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	 
	 	public function __construct()
		{
			error_reporting(0);
			parent::__construct();
			$this->load->database();
			$this->load->library(array('ion_auth','form_validation','pagination'));
			$this->load->helper(array('url','language','form'));
			$this->load->model('connection_model');
			$this->load->model('location_model');
            $this->locations = $this->location_model->getLocations();
 			$this->form_validation->set_error_delimiters($this->config->item('error_start_delimiter', 'ion_auth'), $this->config->item('error_end_delimiter', 'ion_auth'));
	if (!$this->ion_auth->logged_in()): redirect('/auth/login'); endif;
	//print_r($this->locations);
	//exit;
			$this->lang->load('auth');
            if (!$this->ion_auth->logged_in()): redirect('/auth/login'); endif;
		}
		
		public function upload(){
				$this->load->model('csv_model');
				echo $this->csv_model->uploadData();	
				exit;					
		}
	
        
        public function export($type){        	
        $this->load->library('excel');
        
        switch ($type){
           case 'ExportLocation':
                    $tdate = ($this->input->post("tdate"))? strtotime($this->input->post("tdate")) : ""; 
					$fdate = ($this->input->post("fdate"))? strtotime($this->input->post("fdate")) : "";  	
						
                     if($tdate){               
                        $resultdata = $this->connection_model->fetchdata(1000, 0, $fdate, $tdate);
						foreach($resultdata as $item){
                            $fields = array();
                            $fields['Date'] = $item->tdate;
                            $fields['Location'] = $item->location;
                            $fields['Cash Amount'] = $item->camt;
                            $fields['Deposit Amount'] = $item->damt;
							$fields['Diff'] = $item->damt - $item->camt;
							$fields['Amlount'] = $item->aamt;
                            $fields['Comment'] = ($item->comment == 'Others')? $item->other_comment : $item->comment;
				
           					$fields['collection'] = $this->connection_model->get_files_for_export($item->tid);
           					 
						
							
                            $result[] = $fields;
                        }     
						
						
						
                      }    
            break; 
            case 'ExportLocationWise':
            
                $sdate = ($this->input->post("sdate"))? $this->input->post("sdate") : "";
                $edate = ($this->input->post("edate"))? $this->input->post("edate") : "";  
                $type = ($this->input->post("type"))? $this->input->post("type") : "";  
                     if($sdate){               
                        $resultdata = $this->connection_model->FetchLocationData(1000, 0, $type, $sdate , $edate);
                        foreach($resultdata as $item){
                            $fields = array();
                            $fields['Location'] = $item->location;
                            $fields['Collection'] = $item->sumcamt;
                            $fields['Deposite'] = $item->sumdamt;
                            $fields['Difference'] = number_format((float)$item->sumcamt - (float)$item->sumdamt, 2,'.', '');
                            $fields['Unadj Diff'] = number_format((float)$fields['Difference']  - (float)$item->sumaamt, 2,'.', '');
                            $result[] = $fields;
                        }                   
                   }    
            break;
             case 'ExportClosing':
                    $tdate = ($this->input->post("tdate"))? $this->input->post("tdate") : "";  
                  $filter = ($this->input->post("type"))? $this->input->post("type") : "";  
        
                     if($tdate){
                         list($month, $year) = explode('-', $tdate);
                        $resultdata = $this->connection_model->FetchClosingLocationData(1000, 0, $filter, $month, $year);
                      }  
                      
                      foreach($resultdata as $item){
                            $fields = array();
                            $fields['Location'] = $item->location;
                            $fields['Collection'] = $item->sumcamt;
                            $fields['Deposite'] = $item->sumdamt;
                            $fields['Difference'] = number_format((float)$item->sumcamt - (float)$item->sumdamt, 2,'.', '');
                            $fields['Adjustment'] = $item->aamt;
                            $fields['Unadj Diff'] = number_format((float)$fields['Difference']  - (float)$item->sumaamt, 2,'.', '');
                            $fields['Remark'] = $item->remark;
                            $result[] = $fields;
                        }                            
            break; 
            case 'LocationCollection':
                $sdate = ($this->input->post("sdate"))? $this->input->post("sdate") : "";
                $edate = ($this->input->post("edate"))? $this->input->post("edate") : "";  
                $location = ($this->input->post("location"))? $this->input->post("location") : "";  
                $resultdata = $this->connection_model->LocationConnection(1000, 0, $location, $sdate, $edate);
             
                      foreach($resultdata as $item){
                            $fields = array();
                            $fields['Date'] = $item->tdate;
                            $fields['Location'] = $item->location;
                            $fields['Deposite'] = $item->damt;
                            $fields['Difference'] = number_format((float)$item->camt - (float)$item->damt, 2,'.', '');
                            $fields['Adjustment'] = $item->aamt;
                            $fields['Remark'] = $item->comment;
                            $result[] = $fields;
                        }                            
            break; 
        }
                  
        
        foreach ($result as $value){
        $array[] = (array)$value;
        }
      
      
       $this->excel->generateCsv($array, "download.csv");   
           exit;
   
        }
        
	
	public function update(){

			if($this->input->post('tdate')){
				$count = 0;
					foreach($this->input->post('tdate') as $key => $date)
						{
								$inserTdata = array();
								$inserTdata['tdate'] = $date;
								$inserTdata['location'] = $this->input->post('location')[$key];
								$inserTdata['camt'] = $this->input->post('camt')[$key];
								$this->connection_model->insertData($inserTdata);
							$count ++;
						}
				echo $count;
				exit;				
			}
			
			
			
	
		  	$this->data['collection']= $this->connection_model->fetchtempdata();
			$this->load->view('collectionupdate',$this->data, false);
	}

		public function index($fdate = NULL, $tdate = NULL)
	{
		
		$tdate                          = ($this->input->post("tdate"))? strtotime($this->input->post("tdate")) : "NULL";
        $fdate                          = $tdate;
                
		$tdate                          = ($this->uri->segment(4)) ? $this->uri->segment(4) : $tdate;
        $fdate                          = ($this->uri->segment(3)) ? $this->uri->segment(3) : $fdate;
	

		$config["base_url"] 			= base_url() . "collection/index/".$fdate."/".$tdate;
		$config["total_rows"] 			= $this->connection_model->record_count($fdate, $tdate);
		$config["per_page"] 			= 200;
		$config["uri_segment"] 			= 5;
		$config["num_links"] 			= 10;
		$config['full_tag_open'] 		= "<ul class='pagination' id='ajax_pagingsearc'>";
		$config['full_tag_close'] 		= "</ul>";
		$config['num_tag_open'] 		= '<li>';
		$config['num_tag_close'] 		= '</li>';
		$config['cur_tag_open'] 		= "<li class='disabled'><li class='active'><a href='#'>";
		$config['cur_tag_close'] 		= "<span class='sr-only'></span></a></li>";
		$config['next_tag_open'] 		= "<li>";
		$config['next_tagl_close'] 		= "</li>";
		$config['prev_tag_open'] 		= "<li>";
		$config['prev_tagl_close'] 		= "</li>";
		$config['first_tag_open'] 		= "<li>";
		$config['first_tagl_close'] 	= "</li>";
		$config['last_tag_open'] 		= "<li>";
		$config['last_tagl_close'] 		= "</li>";

    	$this->pagination->initialize($config);
	    $page = ($this->uri->segment(5))? $this->uri->segment(4) : 0;
        $this->data['collection']= $this->connection_model->fetchdata($config["per_page"], $page, $fdate, $tdate);
		$this->data["links"] = $this->pagination->create_links();
		$this->data['tdate'] = $tdate;
        $this->data['title'] = "Load Daily Cash";
		if($tdate !== 'NULL'){
                $this->load->view('collectionajaxview',$this->data, false);
		}else{  $this->load->view('collection',$this->data, false); }
	}
	public function indexnew($tdate = NULL)
	{
        
        
         $this->load->view('indexnew',$this->data, false);
    }
	public function indexupdate($fdate = NULL, $tdate = NULL)
	{
		$tdate                          = ($this->input->post("tdate"))? strtotime($this->input->post("tdate")) : "NULL";
        $fdate                          = ($this->input->post("fdate"))? strtotime($this->input->post("fdate")) : "NULL";
                
		$tdate                          = ($this->uri->segment(4)) ? $this->uri->segment(4) : $tdate;
        $fdate                          = ($this->uri->segment(3)) ? $this->uri->segment(3) : $fdate;
		
               
                $config["base_url"] 			= base_url() . "collection/indexupdate/".$fdate."/".$tdate;
		$config["total_rows"] 			= $this->connection_model->record_count($fdate, $tdate);
		$config["per_page"] 			= 600;
		$config["uri_segment"] 			= 5;
		$config["num_links"] 			= 10;
		$config['full_tag_open'] 		= "<ul class='pagination' id='ajax_pagingsearc'>";
		$config['full_tag_close'] 		= "</ul>";
		$config['num_tag_open'] 		= '<li>';
		$config['num_tag_close'] 		= '</li>';
		$config['cur_tag_open'] 		= "<li class='disabled'><li class='active'><a href='#'>";
		$config['cur_tag_close'] 		= "<span class='sr-only'></span></a></li>";
		$config['next_tag_open'] 		= "<li>";
		$config['next_tagl_close'] 		= "</li>";
		$config['prev_tag_open'] 		= "<li>";
		$config['prev_tagl_close'] 		= "</li>";
		$config['first_tag_open'] 		= "<li>";
		$config['first_tagl_close']             = "</li>";
		$config['last_tag_open'] 		= "<li>";
		$config['last_tagl_close'] 		= "</li>";

    	$this->pagination->initialize($config);
	$page = ($this->uri->segment(5))? $this->uri->segment(5) : 0;
        $collections = $this->connection_model->fetchdata($config["per_page"], $page, $fdate, $tdate);

            if($collections){
            foreach($collections as $collection){
            $collection->images = $this->connection_model->getFiles($collection->tid);
            $this->data['collection'][] = $collection;
            }
		}
        $this->load->model('remark_model');
        $this->data['remarks']  = $this->remark_model->fetchdata();
		$this->data["links"] = $this->pagination->create_links();
		$this->data['tdate'] = $tdate;
		$this->data['title'] = "Cash Collection Updation";
		
		if($tdate !== 'NULL'){
                       $this->load->view('collectionajaxedit',$this->data, false);
		}else{ $this->load->view('collectionedit',$this->data, false); }
	}

public function locationwise($sdate = NULL, $edate = NULL)
	{
		$sdate = ($this->input->post("sdate"))? $this->input->post("sdate") : "NULL";
		$sdate = ($this->uri->segment(3)) ? $this->uri->segment(3) : $sdate;
		
		$edate = ($this->input->post("edate"))? $this->input->post("edate") : "NULL";
		$edate = ($this->uri->segment(4)) ? $this->uri->segment(4) : $edate;
		
		$type = ($this->input->post("type"))? $this->input->post("type") : "NULL";
		$type = ($this->uri->segment(5)) ? $this->uri->segment(5) : $type;
		
		$config                 		= array();
		$config["base_url"] 			= base_url() . "collection/locationwise/".$sdate.'/'.$edate.'/'.$type;
		$config["total_rows"] 			= $this->connection_model->LocationRecordCount($type, $sdate, $edate);
		$config["per_page"] 			= 200;
		$config["uri_segment"] 			= 6;
		$config["num_links"] 			= 10;
		$config['full_tag_open'] 		= "<ul class='pagination' id='ajax_pagingsearc'>";
		$config['full_tag_close'] 		= "</ul>";
		$config['num_tag_open'] 		= '<li>';
		$config['num_tag_close'] 		= '</li>';
		$config['cur_tag_open'] 		= "<li class='disabled'><li class='active'><a href='#'>";
		$config['cur_tag_close'] 		= "<span class='sr-only'></span></a></li>";
		$config['next_tag_open'] 		= "<li>";
		$config['next_tagl_close'] 		= "</li>";
		$config['prev_tag_open'] 		= "<li>";
		$config['prev_tagl_close'] 		= "</li>";
		$config['first_tag_open'] 		= "<li>";
		$config['first_tagl_close']             = "</li>";
		$config['last_tag_open'] 		= "<li>";
		$config['last_tagl_close'] 		= "</li>";

    	$this->pagination->initialize($config);
	    $page = ($this->uri->segment(6))? $this->uri->segment(6) : 0;
        $this->data['collection'] = $this->connection_model->FetchLocationData($config["per_page"], $page, $type, $sdate, $edate);
		
		$this->data["links"] 	= $this->pagination->create_links();
		$this->data['sdate'] 	= $sdate;
		$this->data['edate'] 	= $edate;
		$this->data['type'] 	= $type;
		$this->data['title'] = "Location Wise Riconcilation";

		if($sdate !== 'NULL'){
			$this->load->view('collectionajaxlocation',$this->data, false);
		}else{ $this->load->view('collectionlocation',$this->data, false); }
	}
	
	
	public function locationconnections($sdate = NULL, $edate = NULL, $location)
	{
		$sdate = ($this->input->post("sdate"))? $this->input->post("sdate") : "NULL";
		$sdate = ($this->uri->segment(3)) ? $this->uri->segment(3) : $sdate;
		
		$edate = ($this->input->post("edate"))? $this->input->post("edate") : "NULL";
		$edate = ($this->uri->segment(4)) ? $this->uri->segment(4) : $edate;
		
		$location = ($this->input->post("location"))? $this->input->post("location") : "NULL";
		$location = ($this->uri->segment(5)) ? $this->uri->segment(5) : $location;
		
		$this->load->model('remark_model');
		
		$config                 		= array();
		$config["base_url"] 			= base_url() . "collection/locationconnections/".$sdate.'/'.$edate.'/'.$location;
		$config["total_rows"] 			= $this->connection_model->LocationConnectionRecordCount($location, $sdate, $edate);
		$config["per_page"] 			= 200;
		$config["uri_segment"] 			= 6;
		$config["num_links"] 			= 10;
		$config['full_tag_open'] 		= "<ul class='pagination' id='ajax_paginglocation'>";
		$config['full_tag_close'] 		= "</ul>";
		$config['num_tag_open'] 		= '<li>';
		$config['num_tag_close'] 		= '</li>';
		$config['cur_tag_open'] 		= "<li class='disabled'><li class='active'><a href='#'>";
		$config['cur_tag_close'] 		= "<span class='sr-only'></span></a></li>";
		$config['next_tag_open'] 		= "<li>";
		$config['next_tagl_close'] 		= "</li>";
		$config['prev_tag_open'] 		= "<li>";
		$config['prev_tagl_close'] 		= "</li>";
		$config['first_tag_open'] 		= "<li>";
		$config['first_tagl_close'] 	= "</li>";
		$config['last_tag_open'] 		= "<li>";
		$config['last_tagl_close'] 		= "</li>";

    	$this->pagination->initialize($config);
	    $page = ($this->uri->segment(6))? $this->uri->segment(6) : 0;
		$this->data['collection'] = $this->connection_model->LocationConnection($config["per_page"], $page, $location, $sdate, $edate);
		$this->data["links"] = $this->pagination->create_links();
		$this->data['sdate'] = $sdate;
		$this->data['edate'] = $edate;
		$this->data['location'] = str_replace("%20", ' ',$location);
				
		$this->data['remarks']  = $this->remark_model->fetchdata();
		$this->load->view('locationcollectionajax', $this->data, false);
	}
	
	public function closing($month = NULL, $year = NULL)
	{
	
		
		$month = ($this->uri->segment(3)) ? $this->uri->segment(3) : $month;
		$year = ($this->uri->segment(4)) ? $this->uri->segment(4) : $year;
		if($this->input->post("sdate")){
		list($month, $year) = explode("-", $this->input->post("sdate"));
		}
		$filter = ($this->input->post("filter"))? $this->input->post("filter") : 0;
		$filter = ($this->uri->segment(5)) ? $this->uri->segment(5) : $filter;
	
		$this->load->model('remark_model');
		$config                 		= array();
		$config["base_url"] 			= base_url() . "collection/closing/".$month.'/'.$year.'/'.$filter;
		$config["total_rows"] 			= $this->connection_model->LocationClosingRecordCount($month, $year, $filter);
		$config["per_page"] 			= 200;
		$config["uri_segment"] 			= 6;
		$config["num_links"] 			= 10;
		$config['full_tag_open'] 		= "<ul class='pagination' id='ajax_pagingsearc'>";
		$config['full_tag_close'] 		= "</ul>";
		$config['num_tag_open'] 		= '<li>';
		$config['num_tag_close'] 		= '</li>';
		$config['cur_tag_open'] 		= "<li class='disabled'><li class='active'><a href='#'>";
		$config['cur_tag_close'] 		= "<span class='sr-only'></span></a></li>";
		$config['next_tag_open'] 		= "<li>";
		$config['next_tagl_close'] 		= "</li>";
		$config['prev_tag_open'] 		= "<li>";
		$config['prev_tagl_close'] 		= "</li>";
		$config['first_tag_open'] 		= "<li>";
		$config['first_tagl_close'] 	= "</li>";
		$config['last_tag_open'] 		= "<li>";
		$config['last_tagl_close'] 		= "</li>";

    
	    $page = ($this->uri->segment(6))? $this->uri->segment(6) : 0;
        $this->data['collection'] = $this->connection_model->FetchClosingLocationData($config["per_page"], $page, $filter, $month, $year);
		$this->pagination->initialize($config);
		$this->data["links"] 	= $this->pagination->create_links();
		$this->data['month'] 	= $month;
		$this->data['year'] 	= $year;
		$this->data['filter'] 	= $filter;
		$this->data['remarks']  = $this->remark_model->fetchdata();
		$this->data['title'] 	= "Closing";
		if($month){
			$this->load->view('closingajax',$this->data, false);
		}else{ $this->load->view('closinglocations',$this->data, false); }
	}
	
	public function uploadfile(){
	
	 $data = array();

        if(!empty($_FILES['userFiles']['name'])){
		
		
			$tdate = $this->connection_model->getConnection($_POST['case_id']);
				$filesCount 				= count($_FILES['userFiles']['name']);
				$path 						= date('Ymd/', strtotime($tdate)); 
				//$uploadPath 				= FCPATH."/files/".$path;
				$uploadPath 				= "C:/wamp/www/cash/uploads/".$path;
				
				
				if (!is_dir($uploadPath)) {	mkdir($uploadPath, 0777, TRUE); }
				
                $config['upload_path'] 		= $uploadPath;
                $config['allowed_types'] 	= '*';
				$config['file_ext_tolower'] = true;
                $config['overwrite'] 		= false;
				$config['encrypt_name'] 	= false;				
				$config['max_size'] 		= '100000000';
				$config['file_name']		= $_POST['case_id'].'_';
				$config['remove_spaces'] 	= true;
				
                $this->load->library('upload', $config);
                $this->upload->initialize($config);
			
			
            for($i = 0; $i < $filesCount; $i++){
                $_FILES['userFile']['name'] 	= $_FILES['userFiles']['name'][$i];
                $_FILES['userFile']['type'] 	= $_FILES['userFiles']['type'][$i];
                $_FILES['userFile']['tmp_name'] = $_FILES['userFiles']['tmp_name'][$i];
                $_FILES['userFile']['error'] 	= $_FILES['userFiles']['error'][$i];
                $_FILES['userFile']['size'] 	= $_FILES['userFiles']['size'][$i];
               		 
                if($this->upload->do_upload('userFile')){
                     $fileData = $this->upload->data();
					// print_r($fileData); exit;
					 $uploadData 				  = array();
					 $uploadData['collection_id'] = $this->input->post("case_id");
                     $uploadData['image'] 		  = $path.$fileData['file_name'];
                     $uploadData['date']          = date("Y-m-d H:i:s");
                   	 $this->connection_model->insertFile($uploadData); 
                }else{
				echo $this->upload->display_errors();
				exit;
				}
            }
		}
		
	echo  $this->connection_model->getFiles($this->input->post("case_id"));
	exit;
	}
	
	public function deletefile($id, $case_id){
		$this->connection_model->deleteFile($case_id); 
		echo $this->connection_model->getFiles($id);
		exit;
	}
	public function updateconnection(){ //error_reporting(2);
//if($this->input->post("approve")) {$data['approved'] 	= $this->input->post("approve"); }
            if($this->input->post("aamt")) { $data['aamt'] 		    = $this->input->post("aamt"); }
            if($this->input->post("remark")) {$data['comment'] 		    = $this->input->post("remark"); }
            if($data['aamt'] > 0 && empty($data['comment'])){ $data['aamt'] =0; }
            if($this->input->post("remarkother")) {$data['other_comment ']  = $this->input->post("remarkother"); }
            if($this->input->post("camt")) {$data['camt']                   = $this->input->post("camt"); }
            if($this->input->post("damt")) {$data['damt'] 			= $this->input->post("damt"); }
			
			//if($this->input->post("amtdiff")) {$data['amtdiff'] 	= $this->input->post("amtdiff"); }
			
			
			$this->connection_model->update($data, $this->input->post("id"));	
	}
	
	public function savelocation(){
	
		if($this->input->post("sdate")){		
		list($month, $year) = explode("-", $this->input->post("sdate"));
		}
		
		if($this->input->post("location")){
			foreach($this->input->post("location") as $location){	
			
			$query = $this->db->get_where('closing', array('month' => $month, 'year' => $year, 'location' => $location));
		
			if($query->num_rows() > 0){
			//$array['locked'] = $this->input->post("locking_type");
  
			$array['remark'] = $this->input->post("remark")[md5($location)];
            
			$this->db->where('id', $query->row()->id);
			$this->db->update('closing', $array); 
			}else{
			$array = array();
			$array['month'] = $month;
 			$array['year'] = $year;
			$array['location'] = $location;
			//$array['locked '] = $this->input->post("locking_type");
			$array['remark'] = $this->input->post("remark")[md5($location)];
	
			$this->db->insert('closing', $array); 

			}			
			}
		}
		
	echo '';
	exit;
	
	}
	
	public function locklocation(){
		if($this->input->post("sdate")){		
		list($month, $year) = explode("-", $this->input->post("sdate"));
		}
		
		if($this->input->post("location")){
			foreach($this->input->post("location") as $location){	
			$query = $this->db->get_where('closing', array('month' => $month, 'year' => $year, 'location' => $location));
		
			if($query->num_rows() > 0){
			$array['locked'] = $this->input->post("locking_type");
			$this->db->where('id', $query->row()->id);
			$this->db->update('closing', $array); 
			}else{
			$array = array();
			$array['month'] = $month;
 			$array['year'] = $year;
			$array['location'] = $location;
			$array['locked '] = $this->input->post("locking_type");
			//$array['remark'] = $this->input->post("remark")[md5($location)];
	
			$this->db->insert('closing', $array); 

			}			
			}
		}
		
	echo '';
	exit;
	
	}
	
	public function updateremark(){
		if($this->input->post("remark")){
			$query = $this->db->get_where('remarks', array('value' => $this->input->post("remark")));
			if($query->num_rows() == 0){
			$array = array();
			$array['value'] = $this->input->post("remark");
 			$array['date']  = 'Y-m-d h:i';
				$this->db->insert('remarks', $array); 
				}			
			}
		echo 'success'; exit;
	
	}
	
	
}
