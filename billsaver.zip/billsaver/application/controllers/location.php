<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Location extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	 
	 	public function __construct()
		{
			error_reporting(0);
			parent::__construct();
			$this->load->database();
			$this->load->library(array('ion_auth','form_validation','pagination'));
			$this->load->helper(array('url','language','form'));
			$this->load->model('location_model');
		}
        public function index(){
            $this->data['locations'] = $this->location_model->getAll();
			$this->data['title'] 	= "All Locations";
            $this->load->view('location_index', $this->data);
        }
        public function add(){
            $this->load->model('location_model');
            if($this->input->post("locid")){
            $this->data['locid'] = $this->input->post("locid"); 
            $this->data['location'] = $this->input->post("location"); 
            $this->location_model->add($this->data);
            redirect('location/index');
            }
            $this->load->view('add_location',$this->data, false);
            
        }
        public function edit($id){ 
            if($this->input->post("locid")){
            $data['location'] = $this->input->post("location");
            $data['DIRECTOR'] = $this->input->post("DIRECTOR");    
            $data['PM'] = $this->input->post("PM");    
            $data['DM'] = $this->input->post("DM");    
            $data['isActive'] = $this->input->post("isActive");    
            $data['startDate'] = $this->input->post("startDate");        
            $data['endDate'] = $this->input->post("endDate");    

            $this->location_model->edit($data, $this->input->post("locid"));
            redirect('location/index');
            }
            
            $this->data['location'] = $this->location_model->getLocation($id);
            $users = $this->ion_auth->users(array(6,7,8))->result(); // Pass groups array as params
            $this->data['users'][''] = '-- Select --';

			
            foreach($users as $user){
            $this->data['users'][trim($user->first_name).' '.trim($user->last_name)] = $user->first_name.' '.$user->last_name;
            }
            $this->load->view('edit_location',$this->data, false);
        }
       public function delete($id){
           
            $this->location_model->delete($id);
            redirect('location/index');
       } 
}
    