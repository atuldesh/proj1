<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Jobs extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	 
	 	public function __construct()
		{
			error_reporting(1);
			parent::__construct();
			$this->load->database();
			$this->load->library(array('ion_auth','form_validation','pagination'));
			$this->lang->load('auth');
			$this->load->helper(array('url','language','form'));
			
			$this->load->model('jobs_model');
 			$this->form_validation->set_error_delimiters($this->config->item('error_start_delimiter', 'ion_auth'), $this->config->item('error_end_delimiter', 'ion_auth'));
			if (!$this->ion_auth->logged_in()): redirect('/auth/login'); endif;
			        
		}
		
	public function save($id = NULL){
		if($this->input->post('jobid')){
			$jobdata['jobid'] = $this->input->post('jobid');
			$jobdata['imeino'] = $this->input->post('imeino');
			$jobdata['jdate'] = date('Y-m-d', strtotime($this->input->post('jdate')));
			$jobdata['createdBy'] = $this->input->post('createdBy');
			$jobdata['ownerName'] = $this->input->post('ownerName');
			$jobdata['ownerAddr'] = $this->input->post('ownerAddr');
			$jobdata['ownerMob'] = $this->input->post('ownerMob');
			$jobdata['currentHolder'] = $this->input->post('currentHolder');
			$jobdata['status'] = $this->input->post('status');
			$jobdata['statusChangeDate'] = date('Y-m-d', strtotime($this->input->post('statusChangeDate')));
			$jobdata['statusChangeBy'] = $this->input->post('statusChangeBy');
			$jobdata['remark'] = $this->input->post('remark');
			
			if($this->input->post('id'))
			{
			  $this->jobs_model->update($jobdata, $this->input->post('id'));    
				
			}else{
			$this->jobs_model->insert($jobdata);    
			}
			redirect('jobs/index');
		}
		if($id){
			$job = $this->jobs_model->jobs($id);
			$this->data['job'] = $job;
		}
			 $this->data['jobid'] = array('name' => 'jobid',
			'id'    => 'jobid',
			'type'  => 'text',
			'class'  => 'form-control',
			'required' => 'required',
			'value' => $this->form_validation->set_value('jobid', $job->jobid),
		);   
			 $this->data['imeino'] = array('name' => 'imeino',
			'id'    => 'imeino',
			'type'  => 'text',
			'class'  => 'form-control',
			'required' => 'required',
			'value' => $this->form_validation->set_value('imeino', $job->imeino),
		);   
			  $this->data['jdate'] = array('name' => 'jdate',
			'id'    => 'jdate',
			'type'  => 'text',
			'class'  => 'form-control',
			'required' => 'required',
			'value' => $this->form_validation->set_value('jdate', $job->jdate),
		); 
			  $this->data['createdBy'] = array('name' => 'createdBy',
			'id'    => 'createdBy',
			'type'  => 'text',
			'class'  => 'form-control',
			'required' => 'required',
			'value' => $this->form_validation->set_value('createdBy', $job->createdBy),
		);  
			  $this->data['ownerName'] = array('name' => 'ownerName',
			'id'    => 'ownerName',
			'type'  => 'text',
			'class'  => 'form-control',
			'required' => 'required',
			'value' => $this->form_validation->set_value('ownerName', $job->ownerName),
		);  
			  $this->data['ownerAddr'] = array('name' => 'ownerAddr',
			'id'    => 'ownerAddr',
			'type'  => 'text',
			'class'  => 'form-control',
			'required' => 'required',
			'value' => $this->form_validation->set_value('ownerAddr', $job->ownerAddr),
		);  
			 $this->data['ownerMob'] = array('name' => 'ownerMob',
			'id'    => 'ownerMob',
			'type'  => 'text',
			'class'  => 'form-control',
			'required' => 'required',
			'value' => $this->form_validation->set_value('ownerMob', $job->ownerMob),
		);
			 $this->data['currentHolder'] = array('name' => 'currentHolder',
			'id'    => 'currentHolder',
			'type'  => 'text',
			'class'  => 'form-control',
			'required' => 'required',
			'value' => $this->form_validation->set_value('currentHolder', $job->currentHolder),
		);
			 $this->data['status'] = array('name' => 'status',
			'id'    => 'status',
			'type'  => 'text',
			'class'  => 'form-control',
			'required' => 'required',
			'value' => $this->form_validation->set_value('status', $job->status),
		);
			 $this->data['statusChangeDate'] = array('name' => 'statusChangeDate',
			'id'    => 'statusChangeDate',
			'type'  => 'text',
			'class'  => 'form-control',
			'required' => 'required',
			'value' => $this->form_validation->set_value('statusChangeDate', $job->statusChangeDate),
		);
			 $this->data['statusChangeBy'] = array('name' => 'statusChangeBy',
			'id'    => 'statusChangeBy',
			'type'  => 'text',
			'class'  => 'form-control',
			'required' => 'required',
			'value' => $this->form_validation->set_value('statusChangeBy', $job->statusChangeBy),
		);
		
			   $this->data['remark'] = array('name' => 'remark',
			'id'    => 'remark',
			'type'  => 'text',
			'class'  => 'form-control',
			'required' => 'required',
			'value' => $this->form_validation->set_value('remark', $job->remark),
		);   
		$this->data['title'] = "Update Job";	
		$this->load->view('jobs_save', $this->data, false);	
	}

        
        public function index($fdate = NULL, $tdate = NULL)
	{
	
	
	if($fdate && $tdate){
            $fdate                          = ($this->uri->segment(3)) ? $this->uri->segment(3) : $tdate;
            $tdate                          = ($this->uri->segment(4)) ? $this->uri->segment(4) : $fdate; 
            $ajax                           = true;
        }elseif($this->input->post("fdate")){
            $fdate                          = strtotime(($this->input->post("fdate"))? $this->input->post("fdate") : date('Y-m-d'));
            $tdate                          = strtotime(($this->input->post("tdate"))? $this->input->post("tdate") : date('Y-m-d'));
            $ajax                           = true;
        }else{   
            $fdate                          =  strtotime(date('Y-m-d'));
            $tdate                          =  strtotime(date('Y-m-d'));
            $ajax                           = false;
        }
        
	

		$config["base_url"] 			= base_url() . "sale/index/".$fdate."/".$tdate;
		$config["total_rows"] 			= $this->jobs_model->fetchdata($fdate, $tdate, true);
		$config["per_page"] 			= 20;
		$config["uri_segment"] 			= 5;
		$config["num_links"] 			= 10;
		$config['full_tag_open'] 		= "<ul class='pagination' id='ajax_pagingsearc'>";
		$config['full_tag_close'] 		= "</ul>";
		$config['num_tag_open'] 		= '<li>';
		$config['num_tag_close'] 		= '</li>';
		$config['cur_tag_open'] 		= "<li class='disabled'><li class='active'><a href='#'>";
		$config['cur_tag_close'] 		= "<span class='sr-only'></span></a></li>";
		$config['next_tag_open'] 		= "<li>";
		$config['next_tagl_close'] 		= "</li>";
		$config['prev_tag_open'] 		= "<li>";
		$config['prev_tagl_close'] 		= "</li>";
		$config['first_tag_open'] 		= "<li>";
		$config['first_tagl_close'] 	= "</li>";
		$config['last_tag_open'] 		= "<li>";
		$config['last_tagl_close'] 		= "</li>";

    	$this->pagination->initialize($config);
	    $page = ($this->uri->segment(5))? $this->uri->segment(4) : 0;
        $this->data['sales']= $this->jobs_model->fetchdata(fdate, $tdate, false, $config["per_page"], $page);
		$this->data["links"] = $this->pagination->create_links();
		$this->data['tdate'] = $tdate;
                $this->data['fdate'] = $fdate;
                $this->data['title'] = "Jobs";
                            
                
		if($ajax){                    
                $this->load->view('jobsajaxview',$this->data, false);
		}else{  $this->load->view('jobs',$this->data, false); }
	}
	
	
	public function delete($id){
		$this->jobs_model->delete($id); 
                redirect('jobs/index');
		exit;
	}
		
}
