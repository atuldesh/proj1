<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Purchase extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	 
	 	public function __construct()
		{
			error_reporting(0);
			parent::__construct();
			$this->load->database();
			$this->load->library(array('ion_auth','form_validation','pagination'));
			$this->load->helper(array('url','language','form'));
			$this->load->model('purchase_model');
 			$this->form_validation->set_error_delimiters($this->config->item('error_start_delimiter', 'ion_auth'), $this->config->item('error_end_delimiter', 'ion_auth'));
            if (!$this->ion_auth->logged_in()): redirect('/auth/login'); endif;
			$this->lang->load('auth');
            if (!$this->ion_auth->logged_in()): redirect('/auth/login'); endif;
		}
		
	public function save($id = NULL){

            if($this->input->post('imeino')){

                $purchasedata['imeino'] = $this->input->post('imeino');
                $purchasedata['company'] = $this->input->post('company');
                $purchasedata['model'] = $this->input->post('model');
                $purchasedata['invoiceno'] = $this->input->post('invoiceno');
                $purchasedata['billedby'] = $this->input->post('billedby');
                $purchasedata['mobileno'] = $this->input->post('mobileno');
                $purchasedata['remark'] = $this->input->post('remark');
                $purchasedata['schemeid'] = $this->input->post('schemeid');
                $purchasedata['pdate'] = date('Y-m-d', strtotime($this->input->post('pdate')));
                
                
                if($this->input->post('id'))
                {
                  $this->purchase_model->update($purchasedata, $this->input->post('id'));    
                }else{
                $this->purchase_model->insert($purchasedata);    
                }
                redirect('purchase/index');
            }
            if($id){
                $purchase = $this->purchase_model->purchase($id);
                $this->data['purchase'] = $purchase;
            }
            
                 $this->data['imeino'] = array('name' => 'imeino',
				'id'    => 'imeino',
				'type'  => 'text',
				'class'  => 'form-control',
				'required' => 'required',
				'value' => $this->form_validation->set_value('imeino', $purchase->imeino),
			);   
                  $this->data['company'] = array('name' => 'company',
				'id'    => 'company',
				'type'  => 'text',
				'class'  => 'form-control',
				'required' => 'required',
				'value' => $this->form_validation->set_value('company', $purchase->company),
			);   
                   $this->data['model'] = array('name' => 'model',
				'id'    => 'model',
				'type'  => 'text',
				'class'  => 'form-control',
				'required' => 'required',
				'value' => $this->form_validation->set_value('model', $purchase->model),
			);   
                    $this->data['pdate'] = array('name' => 'pdate',
				'id'    => 'pdate',
				'type'  => 'text',
				'class'  => 'form-control',
				'required' => 'required',
				'value' => $this->form_validation->set_value('pdate', date('m/d/Y' , strtotime(($purchase->pdate)? $purchase->pdate : date('Y-m-d')))),
			);   
                    $this->data['billedby'] = array('name' => 'billedby',
				'id'    => 'sale_date',
				'type'  => 'text',
				'class'  => 'form-control',
				'required' => 'required',
				'value' => $this->form_validation->set_value('billedby', $purchase->billedby),
			);   
                        $this->data['invoiceno'] = array('name' => 'invoiceno',
				'id'    => 'invoiceno',
				'type'  => 'text',
				'class'  => 'form-control',
				'required' => 'required',
				'value' => $this->form_validation->set_value('invoiceno', $purchase->invoiceno),
			);   
                        $this->data['remark'] = array('name' => 'remark',
				'id'    => 'remark',
				'type'  => 'text',
				'class'  => 'form-control',
				'required' => 'required',
				'value' => $this->form_validation->set_value('remark', $purchase->remark),
			);   
                        $this->data['schemeid'] = array('name' => 'schemeid',
				'id'    => 'schemeid',
				'type'  => 'text',
				'class'  => 'form-control',
				'required' => 'required',
				'value' => $this->form_validation->set_value('schemeid', $purchase->schemeid),
			);
                        $this->data['mobileno'] = array('name' => 'mobileno',
				'id'    => 'schemeid',
				'type'  => 'text',
				'class'  => 'form-control',
				'required' => 'required',
				'value' => $this->form_validation->set_value('mobileno', $purchase->mobileno),
			);
                        
		$this->data['title'] = "Add Purchase";	
		$this->load->view('purchase_save', $this->data, false);	
	}

        
        public function index($fdate = NULL, $tdate = NULL)
	{
	if($fdate && $tdate){
            $fdate                          = ($this->uri->segment(3)) ? $this->uri->segment(3) : $tdate;
            $tdate                          = ($this->uri->segment(4)) ? $this->uri->segment(4) : $fdate; 
            $ajax                           = true;
        }elseif($this->input->post("fdate")){
            $fdate                          = strtotime(($this->input->post("fdate"))? $this->input->post("fdate") : date('Y-m-d'));
            $tdate                          = strtotime(($this->input->post("tdate"))? $this->input->post("tdate") : date('Y-m-d'));
            $ajax                           = true;
        }else{   
            $fdate                          =  strtotime(date('Y-m-d'));
            $tdate                          =  strtotime(date('Y-m-d'));
            $ajax                           = false;
        }
        
	

		$config["base_url"] 			= base_url() . "purchase/index/".$fdate."/".$tdate;
		$config["total_rows"] 			= $this->purchase_model->fetchdata($fdate, $tdate, true);
		$config["per_page"] 			= 20;
		$config["uri_segment"] 			= 5;
		$config["num_links"] 			= 10;
		$config['full_tag_open'] 		= "<ul class='pagination' id='ajax_pagingsearc'>";
		$config['full_tag_close'] 		= "</ul>";
		$config['num_tag_open'] 		= '<li>';
		$config['num_tag_close'] 		= '</li>';
		$config['cur_tag_open'] 		= "<li class='disabled'><li class='active'><a href='#'>";
		$config['cur_tag_close'] 		= "<span class='sr-only'></span></a></li>";
		$config['next_tag_open'] 		= "<li>";
		$config['next_tagl_close'] 		= "</li>";
		$config['prev_tag_open'] 		= "<li>";
		$config['prev_tagl_close'] 		= "</li>";
		$config['first_tag_open'] 		= "<li>";
		$config['first_tagl_close'] 	= "</li>";
		$config['last_tag_open'] 		= "<li>";
		$config['last_tagl_close'] 		= "</li>";

    	$this->pagination->initialize($config);
	    $page = ($this->uri->segment(5))? $this->uri->segment(4) : 0;
        
            $this->data['purchases']= $this->purchase_model->fetchdata($fdate, $tdate, false, $config["per_page"], $page);
		
        
        $this->data["links"] = $this->pagination->create_links();
		$this->data['tdate'] = $tdate;
                $this->data['fdate'] = $fdate;
                $this->data['title'] = "Purchases";
                            
                
		if($ajax){                    
                $this->load->view('purchaseajaxview',$this->data, false);
		}else{  $this->load->view('purchase',$this->data, false); }
	}
	
	
	public function delete($id){
		$this->sale_model->delete($id); 
                redirect('purchase/index');
		exit;
	}
		
}
